module.exports = {
  skipFiles: ['Mocks', 'Legacy', 'Create2Factory'],
};
